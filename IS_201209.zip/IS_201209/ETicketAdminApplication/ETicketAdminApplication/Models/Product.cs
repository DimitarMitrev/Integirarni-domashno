﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ETicketAdminApplication.Models
{
    public class Product
    {
        public Guid Id { get; set; }
        public string MovieName { get; set; }
      
        public string MovieImage { get; set; }

        public string Genre { get; set; }
       
        public string TicketDescription { get; set; }
        
        public int Rating { get; set; }

      
        public int TicketPrice { get; set; }


    }
}
