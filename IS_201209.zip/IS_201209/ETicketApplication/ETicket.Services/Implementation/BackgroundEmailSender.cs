﻿using ETicket.Domain.DomainModels;
using ETicket.Repository.Interface;
using ETicket.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETicket.Services.Implementation
{
    public class BackgroundEmailSender : IBackgroundEmailSender
    {
        private readonly IEmailService _emailService;
        private readonly IRepository<EmailMessage> _emailmessage;

        public BackgroundEmailSender(IEmailService emailService, IRepository<EmailMessage> emailmessage)
        {
            _emailService = emailService;
            _emailmessage = emailmessage;
        }
        public async Task Dework()
        {
            await _emailService.SendEmailAsync(_emailmessage.GetAll().Where(z => !z.Status).ToList());
        }
    }
}
