﻿using ETicket.Domain.DomainModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ETicket.Domain.DTO
{
    public class AddProductToCardDto
    {
        public Product SelectedProduct { get; set; }

        public Guid ProductId { get; set; }

        public int Quantity { get; set; }
    }
}
