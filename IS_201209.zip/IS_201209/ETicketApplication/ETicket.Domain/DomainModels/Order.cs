﻿using ETicket.Domain.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ETicket.Domain.DomainModels
{
   public class Order : BaseEntity
    {
        public string userId { get; set; }
        public ETicketApplicationUser User { get; set; }

        public virtual ICollection<ProductInOrder> Products { get; set; }
    }
}
