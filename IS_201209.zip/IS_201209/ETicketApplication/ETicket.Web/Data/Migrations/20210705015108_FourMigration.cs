﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ETicket.Web.Data.Migrations
{
    public partial class FourMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TicketImage",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "TicketName",
                table: "Products");

            migrationBuilder.AddColumn<string>(
                name: "Genre",
                table: "Products",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "MovieImage",
                table: "Products",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "MovieName",
                table: "Products",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "date",
                table: "Products",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "ProductInShoppingCarts",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Genre",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "MovieImage",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "MovieName",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "date",
                table: "Products");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "ProductInShoppingCarts");

            migrationBuilder.AddColumn<string>(
                name: "TicketImage",
                table: "Products",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TicketName",
                table: "Products",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
